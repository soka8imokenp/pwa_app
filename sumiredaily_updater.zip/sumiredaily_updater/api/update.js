import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const versionFilePath = path.join(process.cwd(), 'public', 'version.json');
    if (fs.existsSync(versionFilePath)) {
      const data = JSON.parse(fs.readFileSync(versionFilePath, 'utf8'));
      const host = req.headers.host || '';
      const proto = req.headers['x-forwarded-proto'] || 'https';
      const baseUrl = `${proto}://${host}`;

      if (data.fileName && !data.downloadUrl.startsWith('http')) {
        data.downloadUrl = `${baseUrl}/${data.fileName.replace(/^\//, '')}`;
      }

      return res.status(200).json(data);
    }

    return res.status(200).json({
      version: 'v1.4.0',
      fileName: 'Daily-Sumire-latest.apk',
      downloadUrl: '/Daily-Sumire-latest.apk',
      fileSize: '7.5 MB',
      releaseNotes: 'Performance improvements and updates from the archive.',
      publishedAt: new Date().toISOString(),
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to read version metadata' });
  }
}
